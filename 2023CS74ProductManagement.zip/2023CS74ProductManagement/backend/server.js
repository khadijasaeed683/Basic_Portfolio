const express = require('express');
const cors = require('cors');
const { testConnection } = require('./config/database');
const productRoutes = require('./routes/products');
const categoryRoutes = require('./routes/categories');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors()); // Enable CORS for all routes
app.use(express.json()); // Parse JSON request bodies
app.use(express.urlencoded({ extended: true })); // Parse URL-encoded bodies

// Request logging middleware
app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.path}`);
    next();
});

// API Routes
app.use('/api/products', productRoutes);
app.use('/api/categories', categoryRoutes);

// Root endpoint
app.get('/', (req, res) => {
    res.json({
        status: 'success',
        message: 'Product Management API',
        version: '1.0.0',
        endpoints: {
            products: '/api/products',
            categories: '/api/categories'
        }
    });
});

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'success',
        message: 'API is running',
        timestamp: new Date().toISOString()
    });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({
        status: 'error',
        message: 'Endpoint not found',
        code: 404
    });
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Error:', err);
    res.status(500).json({
        status: 'error',
        message: 'Internal server error',
        code: 500
    });
});

// Start server
async function startServer() {
    // Test database connection
    const dbConnected = await testConnection();
    
    if (!dbConnected) {
        console.error('⚠️  Server starting without database connection. Please check your database configuration.');
    }

    app.listen(PORT, () => {
        console.log(`🚀 Server running on http://localhost:${PORT}`);
        console.log(`📚 API Documentation:`);
        console.log(`   GET    /api/products`);
        console.log(`   GET    /api/products/:id`);
        console.log(`   POST   /api/products`);
        console.log(`   PUT    /api/products/:id`);
        console.log(`   DELETE /api/products/:id`);
        console.log(`   GET    /api/categories`);
        console.log(`   GET    /api/categories/:id/products`);
    });
}

startServer();

module.exports = app;

