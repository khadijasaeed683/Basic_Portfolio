const express = require('express');
const router = express.Router();
const { pool } = require('../config/database');

/**
 * GET /api/categories
 * Get all categories
 */
router.get('/', async (req, res) => {
    try {
        const result = await pool.query(
            'SELECT * FROM categories ORDER BY name ASC'
        );

        res.json({
            status: 'success',
            data: result.rows
        });
    } catch (error) {
        console.error('Error fetching categories:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to fetch categories',
            code: 500
        });
    }
});

/**
 * GET /api/categories/:id/products
 * Get all products by category ID
 */
router.get('/:id/products', async (req, res) => {
    try {
        const categoryId = parseInt(req.params.id);

        if (isNaN(categoryId)) {
            return res.status(400).json({
                status: 'error',
                message: 'Invalid category ID',
                code: 400
            });
        }

        // First, get category name
        const categoryResult = await pool.query(
            'SELECT * FROM categories WHERE id = $1',
            [categoryId]
        );

        if (categoryResult.rows.length === 0) {
            return res.status(404).json({
                status: 'error',
                message: 'Category not found',
                code: 404
            });
        }

        const categoryName = categoryResult.rows[0].name;

        // Get products by category name
        const productsResult = await pool.query(
            'SELECT * FROM products WHERE category = $1 ORDER BY name ASC',
            [categoryName]
        );

        res.json({
            status: 'success',
            data: productsResult.rows,
            category: categoryResult.rows[0]
        });
    } catch (error) {
        console.error('Error fetching category products:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to fetch category products',
            code: 500
        });
    }
});

module.exports = router;
