const express = require('express');
const router = express.Router();
const { pool } = require('../config/database');

/**
 * GET /api/products
 * Get all products with optional pagination
 */
router.get('/', async (req, res) => {
    try {
        const page = parseInt(req.query.page) || 1;
        const perPage = parseInt(req.query.per_page) || 10;
        const offset = (page - 1) * perPage;
        const search = req.query.search || '';
        const category = req.query.category || '';
        const sortBy = req.query.sort_by || 'id';
        const sortOrder = req.query.sort_order || 'ASC';

        // Build WHERE clause with PostgreSQL parameterized queries
        let whereClause = 'WHERE 1=1';
        const params = [];
        let paramIndex = 1;

        if (search) {
            whereClause += ` AND (name LIKE $${paramIndex} OR description LIKE $${paramIndex + 1})`;
            params.push(`%${search}%`, `%${search}%`);
            paramIndex += 2;
        }

        if (category) {
            whereClause += ` AND category = $${paramIndex}`;
            params.push(category);
            paramIndex++;
        }

        // Validate sort column to prevent SQL injection
        const allowedSortColumns = ['id', 'name', 'price', 'category', 'stock_quantity', 'created_at'];
        const sortColumn = allowedSortColumns.includes(sortBy) ? sortBy : 'id';
        const order = sortOrder.toUpperCase() === 'DESC' ? 'DESC' : 'ASC';

        // Get total count
        const countQuery = `SELECT COUNT(*) as total FROM products ${whereClause}`;
        const countResult = await pool.query(countQuery, params);
        const total = parseInt(countResult.rows[0].total);

        // Get products with pagination
        const limitParam = paramIndex;
        const offsetParam = paramIndex + 1;
        const productsQuery = `SELECT * FROM products ${whereClause} ORDER BY ${sortColumn} ${order} LIMIT $${limitParam} OFFSET $${offsetParam}`;
        const productsResult = await pool.query(productsQuery, [...params, perPage, offset]);

        res.json({
            status: 'success',
            data: productsResult.rows,
            pagination: {
                total: total,
                page: page,
                per_page: perPage,
                total_pages: Math.ceil(total / perPage)
            }
        });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to fetch products',
            code: 500
        });
    }
});

/**
 * GET /api/products/:id
 * Get single product by ID
 */
router.get('/:id', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);

        if (isNaN(productId)) {
            return res.status(400).json({
                status: 'error',
                message: 'Invalid product ID',
                code: 400
            });
        }

        const result = await pool.query(
            'SELECT * FROM products WHERE id = $1',
            [productId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                status: 'error',
                message: 'Product not found',
                code: 404
            });
        }

        res.json({
            status: 'success',
            data: result.rows[0],
            message: 'Product retrieved successfully'
        });
    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to fetch product',
            code: 500
        });
    }
});

/**
 * POST /api/products
 * Create new product
 */
router.post('/', async (req, res) => {
    try {
        const { name, description, price, category, stock_quantity } = req.body;

        // Validation
        if (!name || !price) {
            return res.status(400).json({
                status: 'error',
                message: 'Name and price are required',
                code: 400
            });
        }

        if (isNaN(price) || parseFloat(price) < 0) {
            return res.status(400).json({
                status: 'error',
                message: 'Price must be a valid positive number',
                code: 400
            });
        }

        const stock = stock_quantity ? parseInt(stock_quantity) : 0;
        if (isNaN(stock) || stock < 0) {
            return res.status(400).json({
                status: 'error',
                message: 'Stock quantity must be a valid non-negative integer',
                code: 400
            });
        }

        // Insert product and return the created product
        const result = await pool.query(
            'INSERT INTO products (name, description, price, category, stock_quantity) VALUES ($1, $2, $3, $4, $5) RETURNING *',
            [name, description || null, price, category || null, stock]
        );

        res.status(201).json({
            status: 'success',
            data: result.rows[0],
            message: 'Product created successfully'
        });
    } catch (error) {
        console.error('Error creating product:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to create product',
            code: 500
        });
    }
});

/**
 * PUT /api/products/:id
 * Update existing product
 */
router.put('/:id', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);

        if (isNaN(productId)) {
            return res.status(400).json({
                status: 'error',
                message: 'Invalid product ID',
                code: 400
            });
        }

        const { name, description, price, category, stock_quantity } = req.body;

        // Check if product exists
        const existingResult = await pool.query(
            'SELECT * FROM products WHERE id = $1',
            [productId]
        );

        if (existingResult.rows.length === 0) {
            return res.status(404).json({
                status: 'error',
                message: 'Product not found',
                code: 404
            });
        }

        // Validation
        if (price !== undefined && (isNaN(price) || parseFloat(price) < 0)) {
            return res.status(400).json({
                status: 'error',
                message: 'Price must be a valid positive number',
                code: 400
            });
        }

        if (stock_quantity !== undefined) {
            const stock = parseInt(stock_quantity);
            if (isNaN(stock) || stock < 0) {
                return res.status(400).json({
                    status: 'error',
                    message: 'Stock quantity must be a valid non-negative integer',
                    code: 400
                });
            }
        }

        // Build update query dynamically
        const updates = [];
        const values = [];
        let paramIndex = 1;

        if (name !== undefined) {
            updates.push(`name = $${paramIndex}`);
            values.push(name);
            paramIndex++;
        }
        if (description !== undefined) {
            updates.push(`description = $${paramIndex}`);
            values.push(description);
            paramIndex++;
        }
        if (price !== undefined) {
            updates.push(`price = $${paramIndex}`);
            values.push(price);
            paramIndex++;
        }
        if (category !== undefined) {
            updates.push(`category = $${paramIndex}`);
            values.push(category);
            paramIndex++;
        }
        if (stock_quantity !== undefined) {
            updates.push(`stock_quantity = $${paramIndex}`);
            values.push(parseInt(stock_quantity));
            paramIndex++;
        }

        if (updates.length === 0) {
            return res.status(400).json({
                status: 'error',
                message: 'No fields to update',
                code: 400
            });
        }

        values.push(productId);

        // Update product and return updated product
        const updateQuery = `UPDATE products SET ${updates.join(', ')} WHERE id = $${paramIndex} RETURNING *`;
        const result = await pool.query(updateQuery, values);

        res.json({
            status: 'success',
            data: result.rows[0],
            message: 'Product updated successfully'
        });
    } catch (error) {
        console.error('Error updating product:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to update product',
            code: 500
        });
    }
});

/**
 * DELETE /api/products/:id
 * Delete product
 */
router.delete('/:id', async (req, res) => {
    try {
        const productId = parseInt(req.params.id);

        if (isNaN(productId)) {
            return res.status(400).json({
                status: 'error',
                message: 'Invalid product ID',
                code: 400
            });
        }

        // Check if product exists
        const result = await pool.query(
            'SELECT * FROM products WHERE id = $1',
            [productId]
        );

        if (result.rows.length === 0) {
            return res.status(404).json({
                status: 'error',
                message: 'Product not found',
                code: 404
            });
        }

        // Delete product
        await pool.query('DELETE FROM products WHERE id = $1', [productId]);

        res.json({
            status: 'success',
            message: 'Product deleted successfully'
        });
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({
            status: 'error',
            message: 'Failed to delete product',
            code: 500
        });
    }
});

module.exports = router;
