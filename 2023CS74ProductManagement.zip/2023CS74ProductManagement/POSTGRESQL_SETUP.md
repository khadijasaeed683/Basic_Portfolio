# PostgreSQL Setup Guide for pgAdmin

## Step 1: Create Database in pgAdmin

1. **Open pgAdmin**
   - Launch pgAdmin from your Start menu or desktop

2. **Connect to PostgreSQL Server**
   - If not already connected, enter your PostgreSQL password
   - Default username is usually `postgres`

3. **Create New Database**
   - Right-click on "Databases" in the left panel
   - Select "Create" → "Database..."
   - Database name: `product_management`
   - Owner: `postgres` (default)
   - Click "Save"

## Step 2: Run the Schema SQL

1. **Open Query Tool**
   - Right-click on `product_management` database
   - Select "Query Tool"

2. **Load and Execute Schema**
   - Click "Open File" button (folder icon)
   - Navigate to `database/schema_postgresql.sql`
   - Click "Execute" button (play icon) or press F5

   **OR** copy-paste the SQL from `database/schema_postgresql.sql` into the query tool and execute

## Step 3: Verify Tables Created

In the Query Tool, run:
```sql
SELECT * FROM categories;
SELECT * FROM products;
```

You should see the sample data (3 categories and 3 products).

## Step 4: Configure Backend

1. **Create `.env` file in `backend` folder:**
   ```env
   DB_HOST=localhost
   DB_USER=postgres
   DB_PASSWORD=your_postgres_password
   DB_NAME=product_management
   DB_PORT=5432
   PORT=3000
   ```

2. **Install Dependencies:**
   ```bash
   cd backend
   npm install
   ```

3. **Start Server:**
   ```bash
   npm start
   ```

You should see:
```
✅ Database connected successfully
🚀 Server running on http://localhost:3000
```

## Troubleshooting

### "password authentication failed"
- Check your PostgreSQL password in `.env` file
- Default PostgreSQL user is `postgres`
- If you forgot the password, you may need to reset it

### "database does not exist"
- Make sure you created the `product_management` database in pgAdmin
- Check the database name in `.env` matches exactly

### "connection refused"
- Make sure PostgreSQL service is running
- Check the port (default is 5432)
- Verify PostgreSQL is listening on localhost

### "relation does not exist"
- Make sure you ran the schema SQL file
- Check that tables were created: `SELECT * FROM information_schema.tables WHERE table_schema = 'public';`

## Quick Test

After setup, test the connection:
1. Backend: `http://localhost:3000/api/products` (should return JSON)
2. Frontend: Open `frontend/index.html` (should show products)

## Notes

- PostgreSQL uses port **5432** (not 3306 like MySQL)
- Default user is **postgres** (not root)
- Use `schema_postgresql.sql` (not `schema.sql`)

