// API Base URL
const API_BASE_URL = 'http://localhost:3000/api';

// Global state
let currentPage = 1;
let currentFilters = {
    search: '',
    category: '',
    sortBy: 'id',
    sortOrder: 'ASC'
};

// Initialize application when DOM is ready
$(document).ready(function() {
    loadProducts();
    loadCategories();
    setupEventListeners();
});

/**
 * Setup all event listeners
 */
function setupEventListeners() {
    // Search functionality
    $('#searchBtn').on('click', function() {
        currentFilters.search = $('#searchInput').val();
        currentPage = 1;
        loadProducts();
    });

    $('#searchInput').on('keypress', function(e) {
        if (e.which === 13) { // Enter key
            $('#searchBtn').click();
        }
    });

    $('#clearSearchBtn').on('click', function() {
        $('#searchInput').val('');
        currentFilters.search = '';
        currentPage = 1;
        loadProducts();
    });

    // Filter and sort
    $('#categoryFilter').on('change', function() {
        currentFilters.category = $(this).val();
        currentPage = 1;
        loadProducts();
    });

    $('#sortBy, #sortOrder').on('change', function() {
        currentFilters.sortBy = $('#sortBy').val();
        currentFilters.sortOrder = $('#sortOrder').val();
        currentPage = 1;
        loadProducts();
    });

    // Action buttons
    $('#addProductBtn').on('click', function() {
        openProductModal();
    });

    $('#refreshBtn').on('click', function() {
        loadProducts();
        loadCategories();
        showSuccess('Products refreshed successfully');
    });

    // Modal close
    $('.close, #cancelBtn').on('click', function() {
        closeProductModal();
    });

    // Form submission
    $('#productForm').on('submit', function(e) {
        e.preventDefault();
        saveProduct();
    });

    // Delete confirmation
    $('#confirmDeleteBtn').on('click', function() {
        const productId = $(this).data('product-id');
        deleteProduct(productId);
    });

    $('#cancelDeleteBtn, #closeDeleteModal').on('click', function() {
        $('#deleteModal').hide();
    });

    // Close modal when clicking outside
    $(window).on('click', function(e) {
        if ($(e.target).hasClass('modal')) {
            $('.modal').hide();
        }
    });
}

/**
 * Load all products from API
 */
function loadProducts() {
    showLoading(true);
    hideMessages();

    const params = {
        page: currentPage,
        per_page: 10,
        ...currentFilters
    };

    $.ajax({
        url: `${API_BASE_URL}/products`,
        method: 'GET',
        dataType: 'json',
        data: params,
        success: function(response) {
            if (response.status === 'success') {
                displayProducts(response.data);
                displayPagination(response.pagination);
            } else {
                showError('Failed to load products: ' + (response.message || 'Unknown error'));
            }
        },
        error: function(xhr, status, error) {
            console.error('Error loading products:', error);
            showError('Failed to load products. Please check if the API server is running.');
            displayEmptyState('Failed to load products');
        },
        complete: function() {
            showLoading(false);
        }
    });
}

/**
 * Display products in the table
 */
function displayProducts(products) {
    const tbody = $('#productsTableBody');
    tbody.empty();

    if (products.length === 0) {
        displayEmptyState('No products found');
        return;
    }

    products.forEach(function(product) {
        const row = `
            <tr>
                <td>${product.id}</td>
                <td><strong>${escapeHtml(product.name)}</strong></td>
                <td>${escapeHtml(product.description || 'N/A')}</td>
                <td class="price">$${parseFloat(product.price).toFixed(2)}</td>
                <td>${escapeHtml(product.category || 'N/A')}</td>
                <td class="${product.stock_quantity < 10 ? 'stock-low' : 'stock-ok'}">
                    ${product.stock_quantity}
                </td>
                <td>
                    <button class="btn btn-edit" onclick="editProduct(${product.id})">
                        ✏️ Edit
                    </button>
                    <button class="btn btn-delete" onclick="confirmDelete(${product.id}, '${escapeHtml(product.name)}')">
                        🗑️ Delete
                    </button>
                </td>
            </tr>
        `;
        tbody.append(row);
    });
}

/**
 * Display empty state message
 */
function displayEmptyState(message) {
    const tbody = $('#productsTableBody');
    tbody.html(`<tr><td colspan="7" class="empty-state">${message}</td></tr>`);
}

/**
 * Display pagination controls
 */
function displayPagination(pagination) {
    const paginationDiv = $('#pagination');
    paginationDiv.empty();

    if (!pagination || pagination.total_pages <= 1) {
        return;
    }

    const prevDisabled = currentPage === 1 ? 'disabled' : '';
    const nextDisabled = currentPage === pagination.total_pages ? 'disabled' : '';

    const paginationHTML = `
        <button ${prevDisabled} onclick="changePage(${currentPage - 1})">← Previous</button>
        <span class="page-info">Page ${currentPage} of ${pagination.total_pages} (${pagination.total} total)</span>
        <button ${nextDisabled} onclick="changePage(${currentPage + 1})">Next →</button>
    `;

    paginationDiv.html(paginationHTML);
}

/**
 * Change page
 */
function changePage(page) {
    currentPage = page;
    loadProducts();
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

/**
 * Load categories for filter dropdown
 */
function loadCategories() {
    $.ajax({
        url: `${API_BASE_URL}/categories`,
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                const categoryFilter = $('#categoryFilter');
                const productCategory = $('#productCategory');
                
                // Clear existing options except "All Categories"
                categoryFilter.find('option:not(:first)').remove();
                productCategory.find('option:not(:first)').remove();

                response.data.forEach(function(category) {
                    categoryFilter.append(`<option value="${escapeHtml(category.name)}">${escapeHtml(category.name)}</option>`);
                    productCategory.append(`<option value="${escapeHtml(category.name)}">${escapeHtml(category.name)}</option>`);
                });
            }
        },
        error: function(xhr, status, error) {
            console.error('Error loading categories:', error);
        }
    });
}

/**
 * Open product modal for adding new product
 */
function openProductModal(product = null) {
    const modal = $('#productModal');
    const form = $('#productForm')[0];
    
    if (product) {
        // Edit mode
        $('#modalTitle').text('Edit Product');
        $('#productId').val(product.id);
        $('#productName').val(product.name);
        $('#productDescription').val(product.description || '');
        $('#productPrice').val(product.price);
        $('#productStock').val(product.stock_quantity);
        $('#productCategory').val(product.category || '');
    } else {
        // Add mode
        $('#modalTitle').text('Add New Product');
        form.reset();
        $('#productId').val('');
        clearFormErrors();
    }
    
    modal.show();
}

/**
 * Close product modal
 */
function closeProductModal() {
    $('#productModal').hide();
    $('#productForm')[0].reset();
    clearFormErrors();
}

/**
 * Save product (create or update)
 */
function saveProduct() {
    const productId = $('#productId').val();
    const productData = {
        name: $('#productName').val().trim(),
        description: $('#productDescription').val().trim(),
        price: parseFloat($('#productPrice').val()),
        category: $('#productCategory').val(),
        stock_quantity: parseInt($('#productStock').val()) || 0
    };

    // Validation
    if (!validateProductForm(productData)) {
        return;
    }

    clearFormErrors();
    showLoading(true);

    const isEdit = productId !== '';
    const url = isEdit ? `${API_BASE_URL}/products/${productId}` : `${API_BASE_URL}/products`;
    const method = isEdit ? 'PUT' : 'POST';

    $.ajax({
        url: url,
        method: method,
        contentType: 'application/json',
        dataType: 'json',
        data: JSON.stringify(productData),
        success: function(response) {
            if (response.status === 'success') {
                showSuccess(isEdit ? 'Product updated successfully!' : 'Product created successfully!');
                closeProductModal();
                loadProducts();
                loadCategories(); // Refresh categories in case new one was added
            } else {
                showError('Failed to save product: ' + (response.message || 'Unknown error'));
            }
        },
        error: function(xhr, status, error) {
            console.error('Error saving product:', error);
            const errorMessage = xhr.responseJSON?.message || 'Failed to save product. Please try again.';
            showError(errorMessage);
            
            // Display field-specific errors if available
            if (xhr.responseJSON?.errors) {
                displayFormErrors(xhr.responseJSON.errors);
            }
        },
        complete: function() {
            showLoading(false);
        }
    });
}

/**
 * Validate product form
 */
function validateProductForm(productData) {
    let isValid = true;
    clearFormErrors();

    if (!productData.name || productData.name.length < 2) {
        $('#nameError').text('Product name must be at least 2 characters long');
        isValid = false;
    }

    if (isNaN(productData.price) || productData.price < 0) {
        $('#priceError').text('Price must be a valid positive number');
        isValid = false;
    }

    return isValid;
}

/**
 * Clear form errors
 */
function clearFormErrors() {
    $('.error-text').text('');
}

/**
 * Display form errors
 */
function displayFormErrors(errors) {
    Object.keys(errors).forEach(function(field) {
        $(`#${field}Error`).text(errors[field]);
    });
}

/**
 * Edit product - fetch and display in modal
 */
function editProduct(productId) {
    showLoading(true);

    $.ajax({
        url: `${API_BASE_URL}/products/${productId}`,
        method: 'GET',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                openProductModal(response.data);
            } else {
                showError('Failed to load product: ' + (response.message || 'Unknown error'));
            }
        },
        error: function(xhr, status, error) {
            console.error('Error loading product:', error);
            showError('Failed to load product. Please try again.');
        },
        complete: function() {
            showLoading(false);
        }
    });
}

/**
 * Confirm delete product
 */
function confirmDelete(productId, productName) {
    $('#deleteProductName').text(productName);
    $('#confirmDeleteBtn').data('product-id', productId);
    $('#deleteModal').show();
}

/**
 * Delete product
 */
function deleteProduct(productId) {
    showLoading(true);
    $('#deleteModal').hide();

    $.ajax({
        url: `${API_BASE_URL}/products/${productId}`,
        method: 'DELETE',
        dataType: 'json',
        success: function(response) {
            if (response.status === 'success') {
                showSuccess('Product deleted successfully!');
                loadProducts();
            } else {
                showError('Failed to delete product: ' + (response.message || 'Unknown error'));
            }
        },
        error: function(xhr, status, error) {
            console.error('Error deleting product:', error);
            const errorMessage = xhr.responseJSON?.message || 'Failed to delete product. Please try again.';
            showError(errorMessage);
        },
        complete: function() {
            showLoading(false);
        }
    });
}

/**
 * Show loading indicator
 */
function showLoading(show) {
    if (show) {
        $('#loadingIndicator').show();
    } else {
        $('#loadingIndicator').hide();
    }
}

/**
 * Show error message
 */
function showError(message) {
    const errorDiv = $('#errorMessage');
    errorDiv.text(message).fadeIn();
    setTimeout(function() {
        errorDiv.fadeOut();
    }, 5000);
}

/**
 * Show success message
 */
function showSuccess(message) {
    const successDiv = $('#successMessage');
    successDiv.text(message).fadeIn();
    setTimeout(function() {
        successDiv.fadeOut();
    }, 3000);
}

/**
 * Hide all messages
 */
function hideMessages() {
    $('#errorMessage, #successMessage').hide();
}

/**
 * Escape HTML to prevent XSS
 */
function escapeHtml(text) {
    if (!text) return '';
    const map = {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, function(m) { return map[m]; });
}

