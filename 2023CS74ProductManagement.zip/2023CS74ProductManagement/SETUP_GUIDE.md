# Quick Setup Guide

## Prerequisites Check
- [ ] Node.js installed (v14+)
- [ ] MySQL installed and running
- [ ] npm or yarn package manager

## Step-by-Step Setup

### 1. Database Setup (5 minutes)

**Option A: Using MySQL Command Line**
```bash
mysql -u root -p < database/schema.sql
```

**Option B: Using MySQL Workbench**
1. Open MySQL Workbench
2. Connect to your MySQL server
3. Open `database/schema.sql`
4. Execute all SQL statements

**Option C: Manual SQL Execution**
```sql
CREATE DATABASE product_management;
USE product_management;
-- Then copy and paste all SQL from schema.sql
```

### 2. Backend Setup (3 minutes)

```bash
# Navigate to backend directory
cd backend

# Install dependencies
npm install

# Create environment file
# Windows (PowerShell):
Copy-Item env.example .env
# Linux/Mac:
cp env.example .env

# Edit .env file with your database credentials
# Use any text editor to modify:
# DB_HOST=localhost
# DB_USER=root
# DB_PASSWORD=your_password
# DB_NAME=product_management
```

### 3. Start Backend Server (1 minute)

```bash
# Make sure you're in the backend directory
npm start

# You should see:
# ✅ Database connected successfully
# 🚀 Server running on http://localhost:3000
```

### 4. Frontend Setup (1 minute)

**Option A: Direct File Opening**
- Simply open `frontend/index.html` in your browser
- Note: May have CORS issues - use Option B if problems occur

**Option B: Using Local Server (Recommended)**

**Python:**
```bash
cd frontend
python -m http.server 8000
# Then open http://localhost:8000
```

**Node.js http-server:**
```bash
npx http-server frontend -p 8000
# Then open http://localhost:8000
```

**VS Code Live Server:**
- Install "Live Server" extension
- Right-click `frontend/index.html`
- Select "Open with Live Server"

### 5. Verify Installation

1. **Backend Test:**
   - Open browser: `http://localhost:3000/api/products`
   - Should see JSON response with products

2. **Frontend Test:**
   - Open frontend in browser
   - Should see product table with sample data
   - Try adding/editing/deleting a product

## Troubleshooting

### Database Connection Failed
- ✅ Check MySQL is running: `mysql --version`
- ✅ Verify credentials in `.env` file
- ✅ Test connection: `mysql -u root -p`
- ✅ Ensure database exists: `SHOW DATABASES;`

### Port 3000 Already in Use
- Change PORT in `.env` to another port (e.g., 3001)
- Update `API_BASE_URL` in `frontend/script.js` to match

### CORS Errors in Browser
- Ensure backend server is running
- Check API_BASE_URL in `frontend/script.js` matches backend port
- Use a local server instead of opening HTML directly

### Products Not Loading
- Check browser console (F12) for errors
- Verify backend is running and accessible
- Test API directly: `http://localhost:3000/api/products`

## Testing with Postman

1. Import `POSTMAN_COLLECTION.json` into Postman
2. Make sure backend server is running
3. Test each endpoint
4. Verify responses match expected format

## Next Steps

- ✅ Read `README.md` for detailed documentation
- ✅ Explore API endpoints
- ✅ Test all CRUD operations
- ✅ Customize the interface as needed

## Support

If you encounter issues:
1. Check error messages in console/terminal
2. Verify all prerequisites are installed
3. Ensure database and server are running
4. Review README.md for detailed information

