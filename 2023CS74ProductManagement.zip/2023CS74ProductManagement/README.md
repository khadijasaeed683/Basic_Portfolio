# Product Management System

A complete RESTful API system built with Node.js, Express, and MySQL, featuring a dynamic web interface that consumes the APIs using JavaScript and jQuery.

## 📋 Table of Contents

- [Features](#features)
- [Technologies Used](#technologies-used)
- [Project Structure](#project-structure)
- [Installation](#installation)
- [Database Setup](#database-setup)
- [Running the Application](#running-the-application)
- [API Documentation](#api-documentation)
- [Frontend Usage](#frontend-usage)
- [Testing](#testing)

## ✨ Features

### Backend (Express/MySQL)
- ✅ Complete CRUD operations for products
- ✅ Category management endpoints
- ✅ Search and filter functionality
- ✅ Pagination support
- ✅ Input validation and sanitization
- ✅ Proper error handling
- ✅ CORS enabled for frontend access
- ✅ Prepared statements for SQL security

### Frontend (JavaScript/jQuery)
- ✅ Dynamic product listing with real-time updates
- ✅ Search and filter functionality
- ✅ Sort by various fields
- ✅ Add/Edit products via modal form
- ✅ Delete products with confirmation
- ✅ Loading indicators
- ✅ Error and success notifications
- ✅ Responsive design
- ✅ Pagination controls

## 🛠 Technologies Used

### Backend
- **Node.js** - JavaScript runtime
- **Express.js** - Web framework
- **MySQL2** - MySQL database driver
- **CORS** - Cross-origin resource sharing
- **dotenv** - Environment variable management

### Frontend
- **HTML5** - Markup
- **CSS3** - Styling with modern gradients and animations
- **JavaScript (ES6+)** - Client-side logic
- **jQuery** - DOM manipulation and AJAX calls

## 📁 Project Structure

```
WT/
├── backend/
│   ├── config/
│   │   └── database.js          # Database connection configuration
│   ├── routes/
│   │   ├── products.js          # Product CRUD endpoints
│   │   └── categories.js        # Category endpoints
│   ├── server.js                # Express server setup
│   ├── package.json             # Backend dependencies
│   └── .env.example             # Environment variables template
├── frontend/
│   ├── index.html               # Main HTML file
│   ├── styles.css               # CSS styling
│   └── script.js                # JavaScript/jQuery code
├── database/
│   └── schema.sql               # Database schema and sample data
└── README.md                    # This file
```

## 🚀 Installation

### Prerequisites
- Node.js (v14 or higher)
- MySQL (v5.7 or higher)
- npm or yarn

### Step 1: Clone or Download the Project

Navigate to the project directory:
```bash
cd WT
```

### Step 2: Install Backend Dependencies

```bash
cd backend
npm install
```

### Step 3: Configure Environment Variables

Create a `.env` file in the `backend` directory:

```bash
cp .env.example .env
```

Edit `.env` with your database credentials:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=your_password
DB_NAME=product_management
DB_PORT=3306
PORT=3000
```

## 🗄 Database Setup

### Option 1: Using MySQL Command Line

1. Open MySQL command line or MySQL Workbench
2. Run the schema file:

```bash
mysql -u root -p < database/schema.sql
```

Or in MySQL:

```sql
source database/schema.sql;
```

### Option 2: Manual Setup

1. Create the database:
```sql
CREATE DATABASE product_management;
```

2. Run the SQL commands from `database/schema.sql` in your MySQL client.

The schema includes:
- `products` table with sample data
- `categories` table with sample data

## ▶ Running the Application

### Start the Backend Server

```bash
cd backend
npm start
```

For development with auto-reload:
```bash
npm run dev
```

The server will start on `http://localhost:3000`

### Open the Frontend

1. Open `frontend/index.html` in your web browser
2. Or use a local server (recommended):

```bash
# Using Python
cd frontend
python -m http.server 8000

# Using Node.js http-server
npx http-server frontend -p 8000
```

Then navigate to `http://localhost:8000`

**Note:** If you're opening the HTML file directly, you may need to configure CORS or use a local server due to browser security restrictions.

## 📚 API Documentation

### Base URL
```
http://localhost:3000/api
```

### Product Endpoints

#### Get All Products
```http
GET /api/products
```

**Query Parameters:**
- `page` (optional) - Page number (default: 1)
- `per_page` (optional) - Items per page (default: 10)
- `search` (optional) - Search term for name/description
- `category` (optional) - Filter by category
- `sort_by` (optional) - Sort field (id, name, price, category, stock_quantity)
- `sort_order` (optional) - ASC or DESC (default: ASC)

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Laptop",
      "description": "High-performance laptop",
      "price": 999.99,
      "category": "Electronics",
      "stock_quantity": 15,
      "created_at": "2024-01-01T00:00:00.000Z",
      "updated_at": "2024-01-01T00:00:00.000Z"
    }
  ],
  "pagination": {
    "total": 25,
    "page": 1,
    "per_page": 10,
    "total_pages": 3
  }
}
```

#### Get Single Product
```http
GET /api/products/:id
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "id": 1,
    "name": "Laptop",
    "description": "High-performance laptop",
    "price": 999.99,
    "category": "Electronics",
    "stock_quantity": 15
  },
  "message": "Product retrieved successfully"
}
```

#### Create Product
```http
POST /api/products
Content-Type: application/json
```

**Request Body:**
```json
{
  "name": "New Product",
  "description": "Product description",
  "price": 99.99,
  "category": "Electronics",
  "stock_quantity": 10
}
```

**Response:**
```json
{
  "status": "success",
  "data": {
    "id": 4,
    "name": "New Product",
    "description": "Product description",
    "price": 99.99,
    "category": "Electronics",
    "stock_quantity": 10
  },
  "message": "Product created successfully"
}
```

#### Update Product
```http
PUT /api/products/:id
Content-Type: application/json
```

**Request Body:** (all fields optional)
```json
{
  "name": "Updated Product",
  "price": 149.99,
  "stock_quantity": 20
}
```

#### Delete Product
```http
DELETE /api/products/:id
```

**Response:**
```json
{
  "status": "success",
  "message": "Product deleted successfully"
}
```

### Category Endpoints

#### Get All Categories
```http
GET /api/categories
```

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Electronics",
      "description": "Electronic devices and accessories"
    }
  ]
}
```

#### Get Products by Category
```http
GET /api/categories/:id/products
```

**Response:**
```json
{
  "status": "success",
  "data": [
    {
      "id": 1,
      "name": "Laptop",
      "price": 999.99,
      "category": "Electronics"
    }
  ],
  "category": {
    "id": 1,
    "name": "Electronics"
  }
}
```

### Error Responses

All endpoints return errors in this format:

```json
{
  "status": "error",
  "message": "Error description",
  "code": 404
}
```

**HTTP Status Codes:**
- `200` - Success
- `201` - Created
- `400` - Bad Request (validation error)
- `404` - Not Found
- `500` - Internal Server Error

## 🖥 Frontend Usage

### Features

1. **View Products**
   - Products are automatically loaded on page load
   - Table displays all product information

2. **Search Products**
   - Enter search term in the search box
   - Click "Search" or press Enter
   - Searches in product name and description

3. **Filter by Category**
   - Select a category from the dropdown
   - Products are filtered automatically

4. **Sort Products**
   - Choose sort field and order (ASC/DESC)
   - Products are sorted automatically

5. **Add Product**
   - Click "Add New Product" button
   - Fill in the form (Name and Price are required)
   - Click "Save Product"

6. **Edit Product**
   - Click "Edit" button on any product row
   - Modify the product details
   - Click "Save Product"

7. **Delete Product**
   - Click "Delete" button on any product row
   - Confirm deletion in the modal
   - Product is removed from the list

8. **Pagination**
   - Navigate between pages using Previous/Next buttons
   - Page information is displayed

## 🧪 Testing

### Using Postman

1. Import the following endpoints into Postman:

**Get All Products:**
```
GET http://localhost:3000/api/products
```

**Get Single Product:**
```
GET http://localhost:3000/api/products/1
```

**Create Product:**
```
POST http://localhost:3000/api/products
Content-Type: application/json

{
  "name": "Test Product",
  "description": "Test description",
  "price": 49.99,
  "category": "Electronics",
  "stock_quantity": 5
}
```

**Update Product:**
```
PUT http://localhost:3000/api/products/1
Content-Type: application/json

{
  "price": 59.99,
  "stock_quantity": 10
}
```

**Delete Product:**
```
DELETE http://localhost:3000/api/products/1
```

### Using cURL

```bash
# Get all products
curl http://localhost:3000/api/products

# Get single product
curl http://localhost:3000/api/products/1

# Create product
curl -X POST http://localhost:3000/api/products \
  -H "Content-Type: application/json" \
  -d '{"name":"New Product","price":99.99,"category":"Electronics","stock_quantity":10}'

# Update product
curl -X PUT http://localhost:3000/api/products/1 \
  -H "Content-Type: application/json" \
  -d '{"price":149.99}'

# Delete product
curl -X DELETE http://localhost:3000/api/products/1
```

## 🔒 Security Features

- ✅ Prepared statements to prevent SQL injection
- ✅ Input validation on both client and server
- ✅ XSS protection with HTML escaping
- ✅ CORS configuration
- ✅ Error handling without exposing sensitive information

## 📝 Code Comments

The codebase includes comprehensive comments explaining:
- API endpoint functionality
- Database query logic
- Frontend AJAX operations
- Form validation
- Error handling

## 🐛 Troubleshooting

### Database Connection Issues
- Verify MySQL is running
- Check database credentials in `.env`
- Ensure database `product_management` exists
- Verify user has proper permissions

### CORS Errors
- Ensure backend server is running
- Check CORS configuration in `server.js`
- Verify API base URL in `frontend/script.js`

### Port Already in Use
- Change PORT in `.env` file
- Update API_BASE_URL in `frontend/script.js` accordingly

## 📄 License

This project is created for educational purposes as part of Assignment #6.

## 👨‍💻 Author

Created for REST API Development and Consumption assignment.

---

**Note:** Make sure both the backend server and MySQL database are running before using the frontend interface.

