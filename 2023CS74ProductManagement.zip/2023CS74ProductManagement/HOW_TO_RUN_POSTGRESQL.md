# 🚀 How to Run with PostgreSQL (pgAdmin)

## Quick Start Steps

### 1. Set Up Database in pgAdmin (5 minutes)

1. **Open pgAdmin**
2. **Create Database:**
   - Right-click "Databases" → "Create" → "Database..."
   - Name: `product_management`
   - Click "Save"

3. **Run Schema:**
   - Right-click `product_management` → "Query Tool"
   - Click "Open File" → Select `database/schema_postgresql.sql`
   - Click "Execute" (F5)

### 2. Install Backend Dependencies

```bash
cd backend
npm install
```

### 3. Configure Environment

Create `backend/.env` file:

```env
DB_HOST=localhost
DB_USER=postgres
DB_PASSWORD=your_postgres_password
DB_NAME=product_management
DB_PORT=5432
PORT=3000
```

**Important:** Replace `your_postgres_password` with your actual PostgreSQL password.

### 4. Start Backend Server

```bash
cd backend
npm start
```

You should see:
```
✅ Database connected successfully
🚀 Server running on http://localhost:3000
```

### 5. Open Frontend

Simply open `frontend/index.html` in your browser, or use a local server:

```bash
cd frontend
python -m http.server 8000
```

Then open: `http://localhost:8000`

---

## Troubleshooting

### "password authentication failed"
- Check your PostgreSQL password in `backend/.env`
- Default user is `postgres`

### "database does not exist"
- Make sure you created `product_management` in pgAdmin
- Check database name in `.env` matches exactly

### "connection refused"
- Make sure PostgreSQL service is running
- Default port is **5432** (not 3306)

---

## What's Different from MySQL?

- ✅ Uses PostgreSQL instead of MySQL
- ✅ Port: **5432** (not 3306)
- ✅ User: **postgres** (not root)
- ✅ Use `schema_postgresql.sql` (not `schema.sql`)
- ✅ All SQL syntax converted to PostgreSQL

Everything else works the same! 🎉

